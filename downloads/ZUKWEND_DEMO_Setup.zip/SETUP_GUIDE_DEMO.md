# ZUKWEND DEMO — Guida di installazione

## Requisiti di sistema
- Windows 10 / Windows 11 a 64 bit
- RAM: 4 GB minimi (8 GB raccomandati)
- Spazio su disco: ~150 MB

## Installazione ed Esecuzione
1. Scarica ed estrai `ZUKWEND_DEMO_Setup.zip` in una cartella a scelta (es. `C:\ZUKWEND_DEMO`).
2. Avvia `ZUKWEND.exe` dalla cartella estratta.
3. Se compare l'avviso di Microsoft Defender SmartScreen (*"PC protetto da Windows / App non riconosciuta"*):
   - Clicca su **"Ulteriori informazioni"** (o *"More info"*).
   - Clicca su **"Esegui comunque"** (o *"Run anyway"*).

## Architettura AI Out-of-the-Box
- **Nessuna configurazione o installazione esterna richiesta per iniziare**: ZUKWEND integra il **Level 1 Built-in Native AI Agent**, subito attivo al 100%.
- **Zero Ollama obbligatorio, zero chiavi API richieste**: puoi iniziare ad analizzare i documenti immediatamente dopo il download.
- In qualsiasi momento puoi abilitare opzionalmente:
  - **Level 2 (Local Ollama Power-Up)**: per modelli open-weights locali estesi (Gemma, Mistral, Qwen, DeepSeek).
  - **Level 3 (Cloud BYOC Power-Up)**: per collegare le tue API Key personali (Claude, OpenAI, Gemini, Groq, DeepSeek).

## Primo test pratico
1. Apri ZUKWEND.
2. Carica le fatture fac-simile incluse nella cartella `SAMPLE_INVOICES`.
3. Avvia l'analisi e verifica i report e le bozze generate nella cartella `output`.

## Limiti della DEMO
- 7 giorni di prova o massimo 10 fatture elaborate.
- Per sbloccare la licenza a vita senza limitazioni visita [https://zukwend.com](https://zukwend.com) (249 € una tantum, 2 attivazioni hardware-locked).

## Supporto
Visita [https://zukwend.com](https://zukwend.com) o contatta OLTREVISTA AI ([https://oltrevista.com](https://oltrevista.com)).
