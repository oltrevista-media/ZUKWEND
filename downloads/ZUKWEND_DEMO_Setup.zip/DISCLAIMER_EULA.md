﻿# DISCLAIMER E LICENZA D'USO (EULA) - ZUKWEND

**Ultimo aggiornamento:** 10/10/2026 - Versione software: 2.1.0

Utilizzando ZUKWEND (di seguito "il Software"), sviluppato da OLTREVISTA AI, l'utente dichiara di aver letto e accettato le condizioni seguenti.

## 1. Natura del Software (AI offline)
Il Software opera in modalita offline-first: l'elaborazione dei documenti e le funzioni di intelligenza artificiale vengono eseguite localmente sul computer dell'utente. I documenti e i dati elaborati non vengono inviati a server esterni, salvo l'uso volontario di funzioni opzionali in modalita cloud con una chiave API fornita dall'utente.

## 2. Natura dei risultati e manleva
Gli output generati dal Software (report, classificazioni, deduzioni, solleciti, bozze di comunicazione) sono prodotti da sistemi di intelligenza artificiale e possono contenere errori, omissioni o imprecisioni. Non costituiscono consulenza legale, fiscale, contabile o finanziaria.

L'utente e l'unico responsabile della verifica dei risultati prima di qualsiasi utilizzo e di ogni decisione o azione che ne derivi. Nei limiti consentiti dalla legge, OLTREVISTA AI e i suoi autori sono sollevati da ogni responsabilita per danni diretti, indiretti, incidentali o consequenziali (inclusi mancati incassi, sanzioni, perdita di dati o di opportunita) derivanti dall'uso o dall'impossibilita di usare il Software.

## 3. Gestione dei crediti e della licenza in locale
- Lo stato della licenza, il periodo di prova DEMO (7 giorni, massimo 10 fatture) e l'eventuale contatore dei crediti sono memorizzati localmente sul dispositivo dell'utente (cartella `.zukwend` nel profilo utente), senza verifica continua su server.
- L'utente e responsabile della conservazione di tali file e del codice di licenza. La cancellazione, la modifica o la perdita dei file locali, la reinstallazione del sistema o il cambio di dispositivo possono comportare la perdita di crediti, periodo di prova residuo o attivazione.
- La licenza e personale, legata alla macchina e non cedibile. La manomissione dei meccanismi di licenza e vietata e invalida la licenza.
- I crediti o le licenze perduti per cause riconducibili all'utente non sono rimborsabili ne ripristinabili in modo automatico.

## 4. Privacy e backup
Poiche i dati restano sul dispositivo dell'utente, la sicurezza, il backup e la conformita normativa (inclusa la protezione dei dati personali, GDPR) dei documenti elaborati restano a carico dell'utente.

## 5. Garanzie
Il Software e fornito "cosi com'e" (as is) e "come disponibile", senza garanzie espresse o implicite di commerciabilita, idoneita a uno scopo specifico o assenza di errori.

## 6. Accettazione
L'installazione o l'uso del Software implica l'accettazione integrale del presente documento. In caso di disaccordo, l'utente deve interrompere l'uso e disinstallare il Software.

---
*OLTREVISTA AI - ZUKWEND*
