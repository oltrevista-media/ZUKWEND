# ZUKWEND — Versione DEMO

Versione di prova di **ZUKWEND — Hybrid AR & Billing AI Agent**.

## Limiti della DEMO
- Durata: **7 giorni** dalla prima attivazione
- Massimo **10 fatture** elaborate
- Nessuna licenza attiva inclusa (nessun file `.key` / `.lock`)

## Contenuto del Pacchetto
- Applicazione ZUKWEND (build desktop nativa)
- `SAMPLE_INVOICES/` con fatture PDF fac-simile per provare il prodotto
- `SETUP_GUIDE_DEMO.md` — guida di installazione rapida
- `ISTRUZIONI_INSTALLAZIONE_WINDOWS.txt` & `WINDOWS_INSTALLATION_NOTE.txt` — avvisi Microsoft Defender SmartScreen

## Come iniziare
1. Estrai l'archivio ZIP in una cartella locale a scelta (es. `C:\ZUKWEND_DEMO`).
2. Avvia `ZUKWEND.exe`. Al primo avvio, se compare la schermata blu SmartScreen (*"App non riconosciuta"*), clicca su *"Ulteriori informazioni"* e poi *"Esegui comunque"*.
3. Trascina i file PDF dalla cartella `SAMPLE_INVOICES` ed esegui l'elaborazione.
4. Al termine del periodo di prova, visita [https://zukwend.com](https://zukwend.com) per acquistare la licenza a vita (Lifetime License / 2 attivazioni a 249 € una tantum, zero canoni ricorrenti).

## ARCHITETTURA AI 3-TIER (NATIVE OUT-OF-THE-BOX):

- **Level 1 — Built-in Native AI Agent (Included)**: Software operativo al 100% out-of-the-box dopo l'installazione. Zero configurazioni, zero installazioni esterne, zero Ollama obbligatorio, zero chiavi API richieste per iniziare.
- **Level 2 — Local Ollama Power-Up (Optional)**: Integrazione 1-click per modelli LLM locali estesi (Gemma, Mistral, Qwen, DeepSeek) per massima privacy e autonomia offline.
- **Level 3 — Cloud BYOC Power-Up (Optional)**: Connessione diretta delle proprie API Key personali (Claude, OpenAI, Gemini, DeepSeek, Groq).

## TRANSPARENCY & LEGAL NOTICE:

ZUKWEND is an administrative desktop agent designed for Accounts Receivable (AR) automation, overdue invoice tracking, and reminder draft generation. It is not an active invoicing tool (it does not generate XML/SDI electronic invoices) nor a debt collection agency. All generated outputs must be reviewed by qualified personnel before dispatch.

---
© 2026 **OLTREVISTA AI** — [https://oltrevista.com](https://oltrevista.com) | [https://zukwend.com](https://zukwend.com)
